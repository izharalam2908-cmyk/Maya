# Sirf Android phone se MYRA ULTRA APK banayein (GitHub Actions)

Is project mein `.github/workflows/build-apk.yml` diya gaya hai. GitHub ke cloud runner par Android APK build hota hai; phone par Android SDK install karna zaroori nahi.

## Steps
1. ZIP ko download karke extract karein.
2. GitHub par sign in karke naya **public ya private repository** banayein, naam `myra-ultra-android`.
3. Extracted `myra-android-project` folder ke **andar ki sabhi files aur folders** repository ke root mein upload karein. `.github` hidden folder ko bhi upload karna zaroori hai. GitHub mobile web par folder upload mushkil ho to desktop site mode ya GitHub mobile app/browser ke file picker ka use karein; alternatively repo ko PC se upload karein.
4. Repository mein **Actions** tab kholein. `Build MYRA ULTRA APK` workflow choose karke **Run workflow** dabayein.
5. Build complete hone par run ko kholein → **Artifacts** → `MYRA-ULTRA-debug-apk` download karein.
6. Artifact ZIP ko extract karein; `app-debug.apk` par tap karke install karein. Android prompt aaye to browser/files app ke liye “Install unknown apps” permission sirf zarurat padne par allow karein.

## Notes
- Yeh debug APK hai, Play Store release/signing package nahi.
- Build ke liye repository mein project ke saare source files aur `.github/workflows/build-apk.yml` hona chahiye.
- Gemini API key app ke andar user khud configure karta hai. API key ko public repository, screenshots, ya chat mein share na karein.
- APK app ke mobile companion UI ko wrap karta hai; original Windows/PyQt ke sab features Android par automatically nahi aate.
