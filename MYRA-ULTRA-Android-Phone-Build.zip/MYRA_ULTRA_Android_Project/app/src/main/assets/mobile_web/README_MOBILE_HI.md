# MYRA ULTRA Mobile Companion (Hindi guide)

## Kya add hua?
- `mobile_web/index.html`: phone-first responsive UI, chat, browser voice input/output, Gemini chat connection.
- `mobile_web/manifest.webmanifest` and `mobile_web/sw.js`: PWA install/offline shell support when served from HTTPS.

## Phone par jaldi test
1. ZIP extract karo.
2. `MYRA_ULTRA_APP/mobile_web/index.html` ko phone mein transfer karke Chrome se kholo. (Kuch phones local HTML file open karne mein restrictions laga sakte hain.)
3. Settings → Gemini API key mein apni key paste karo → Save.
4. Assistant tab par message bhejo. Microphone ke liye permission allow karo.

## Home screen par install
PWA installation ke liye `mobile_web` folder ko HTTPS hosting par publish karo, phir Android Chrome mein URL kholo → menu (⋮) → Add to Home screen / Install app.

## Important limitations
- Original MYRA ULTRA desktop app PyQt5/Windows app hai; yeh mobile companion us desktop app ko Android APK mein convert nahi karta.
- This companion talks directly to the Gemini API from the browser. API key browser session storage mein rakhi jaati hai and is not protected from someone using the same device. Don't publish a personal API key or use this client-side design as a public production service. For production, add a secured backend and authentication.
- It does not have Android-wide control, background listening, or direct access to the desktop app's local files. Android restricts these capabilities and they require a native app, explicit permissions, and careful design.
