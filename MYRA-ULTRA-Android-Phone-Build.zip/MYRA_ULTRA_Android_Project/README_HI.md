# MYRA ULTRA Android App project

Yeh Android Studio project MYRA ULTRA ke mobile companion web UI ko Android WebView app mein wrap karta hai.

## APK banane ke liye
1. PC/laptop par Android Studio install karein.
2. Android Studio → Open → is folder `MYRA_ULTRA_Android_Project` ko select karein.
3. Gradle sync complete hone dein; SDK Platform 35 install karne ko kahe to install karein.
4. Test ke liye phone mein USB debugging on karke Run ▶ dabayein.
5. APK ke liye Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK path aam taur par `app/build/outputs/apk/debug/app-debug.apk` hota hai.

## Features / limitations
- Android app launcher icon/name aur native WebView shell.
- Mobile UI, Gemini text chat (API key user khud Settings mein deta hai), browser speech APIs where supported.
- Microphone runtime permission handling.
- Original Windows Python/PyQt desktop features automatically Android par port nahi hote.
- Gemini API key is browser storage mein save hoti hai; shared phone par key save na karein. Production app ke liye secure backend zaroori hai.
- Is environment mein Android SDK/Gradle build available nahi tha, isliye yeh Android Studio project source hai, prebuilt APK nahi.
